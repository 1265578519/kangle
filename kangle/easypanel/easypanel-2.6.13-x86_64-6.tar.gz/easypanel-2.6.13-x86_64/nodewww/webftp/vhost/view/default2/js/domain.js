function domain_add()
{
	var domain = $("#domain").val();
	var subdir = $("#subdir").val();
	$.ajax({
		type:'POST',
		url: '?c=domain&a=add',
		data:'domain=' + domain + '&subdir=' + subdir,
		success:function(msg){
			if (msg != "成功"){
				//document.getElementById("button").disabled=true;
				return alert(msg);
			}
		},
		complete:function(msg){
			show_sync();
			window.location.reload();
		}
	});	
}
function domain_sync()
{
	

}
function domain_del(val,id)
{
	if (confirm("确定要删除?") !=true) {
		return;
	}
	$.ajax({
		type:'POST',
		url: '?c=domain&a=del',
		data:'domain=' + val,
		success:function(msg){
			if(msg != "成功"){
				return alert(msg);
			}
			 //$("#" + id +"t" ).fadeOut(1000);//cdn未实现
		},
		complete:function(msg){
			show_sync();
			window.location.reload();
		}
	});
	
}